<?php
//Este proyecto consiste en :
//Tenemos una clase que almacenamos
//nombre de ciudad
//número de población
//temperatura media anual
//capital de país o no

/*En el archivo index.php creamos una ciudad con los datos anteriores
y muestra su "ficha" utilizando un método.
Debes utilizar encapsulamiento y visibilidad.

Diseña un método que permita:
si la población es +50000 y es capital del país,
muestra un mensaje que indica : "acceso al tráfico restringido".*/

class Ciudad{
   private string $nombre;
   private int $poblacion;
   private float $temperatura;
   private bool $capital;  

    public function __construct($nombre, $poblacion, $temperatura, $capital){
        $this->nombre=$nombre;
        $this->poblacion=$poblacion;
        $this->precio=$temperatura;
        $this->descuento=$capital;
    }

   public function consultarCiudad(){
    if ($this->poblacion>=50000 and $this->nombre=="madrid"){
        echo"<p>Acceso al tráfico restringido en ".$this->nombre."</p>";
    }
    else{
        echo"<p>Acceso por toda la ciudad ".$this->nombre."</p>";
    }
    
    }
}