<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ciudad</title>
</head>
<body>
    <h3>Ciudad</h3>
    <?php
    require_once('lugar.php');
    $ciudad=new Ciudad("logroño", 50000, 15, False);
    $ciudad->consultarCiudad();
    ?>
</body>
</html>